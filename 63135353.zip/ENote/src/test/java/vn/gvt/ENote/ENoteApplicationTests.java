package vn.gvt.ENote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ENoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
