package vn.gvt.ENote.Models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MailStructure {
	private String subject;
	private String body;
}
