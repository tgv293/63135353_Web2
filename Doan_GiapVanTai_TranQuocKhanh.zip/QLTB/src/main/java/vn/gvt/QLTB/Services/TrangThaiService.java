package vn.gvt.QLTB.Services;

import vn.gvt.QLTB.Models.TrangThai;

public interface TrangThaiService {
	public TrangThai findByMaTinhTrang(Integer maTinhTrang);
}
