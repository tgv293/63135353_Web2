package thiGK.ntu63135353.giapvantai_QLSinhVien;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GiapvantaiQlSinhVienApplication {

	public static void main(String[] args) {
		SpringApplication.run(GiapvantaiQlSinhVienApplication.class, args);
	}

}
